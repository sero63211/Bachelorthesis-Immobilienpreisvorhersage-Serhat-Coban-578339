import pandas as pd
import scipy.stats as stats
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
file_path = '../../../../Desktop/HAUS_Regionale_Einordnung.csv'
df = pd.read_csv(file_path)
print("Initial data loaded. Overview of first few rows:")
print(df.head())

# Convert columns to numeric and handle missing values
for col in ['rooms', 'bedrooms', 'bathrooms']:
    df[col] = pd.to_numeric(df[col], errors='coerce')
print("\nData conversion to numeric done. Summary statistics for these columns:")
print(df[['rooms', 'bedrooms', 'bathrooms']].describe())

# Ensure no NaN values remain in the dataset for columns of interest
df_filtered = df.dropna(subset=['rooms', 'bedrooms', 'bathrooms', 'garage_parking', 'price_per_m2', 'buyer_commission', 'living_space', 'property_area'])
print("\nData after removing rows with NaN values in critical columns. Descriptive statistics:")
print(df_filtered.describe())

# Function to perform Mann-Whitney U test
def mannwhitney_u_test(data, category_column, value_column):
    group1 = data[data[category_column] == 'städtisch'][value_column]
    group2 = data[data[category_column] == 'ländlich'][value_column]
    if not group1.empty and not group2.empty:
        u_statistic, p_value = stats.mannwhitneyu(group1, group2, alternative='two-sided')
        print(f"\nPerforming Mann-Whitney U test on {value_column}:")
        print(f"Sample sizes - Urban: {len(group1)}, Rural: {len(group2)}")
        print(f"Median values - Urban: {group1.median()}, Rural: {group2.median()}")
        print(f"U-statistic = {u_statistic}, P-value = {p_value}")
        return u_statistic, p_value
    else:
        print(f"\nInsufficient data to perform test on {value_column}.")
        return None, None

# Additional columns of interest
columns_of_interest = ['price_per_m2', 'rooms', 'bedrooms', 'bathrooms', 'living_space', 'property_area', 'buyer_commission']

# Perform Mann-Whitney U test for each column of interest
test_results = {}
for column in columns_of_interest:
    u_statistic, p_value = mannwhitney_u_test(df_filtered, 'Kategorie', column)
    if u_statistic is not None and p_value is not None:
        test_results[column] = {'U-statistic': u_statistic, 'P-value': p_value}

# Print the final compiled test results
print("\nFinal Compiled Mann-Whitney U Test Results:")
for key, value in test_results.items():
    print(f"{key}: U-statistic = {value['U-statistic']}, P-value = {value['P-value']}")

# Plot distributions for visual comparison individually
for column in columns_of_interest:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Kategorie', y=column, data=df_filtered)
    plt.title(f'{column} by Category (Urban vs Rural)')
    plt.xlabel('Kategorie')
    plt.ylabel(column)
    plt.show()
