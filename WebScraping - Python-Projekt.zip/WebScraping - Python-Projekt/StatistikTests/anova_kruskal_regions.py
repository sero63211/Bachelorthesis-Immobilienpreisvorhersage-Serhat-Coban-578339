import pandas as pd
from scipy.stats import f_oneway, kruskal
import matplotlib.pyplot as plt
import seaborn as sns

# Daten laden
data = pd.read_csv('../../../../Desktop/Cleaned_HAUS_Properties.csv')

# Regionen definieren (Anpassen entsprechend Ihrer Daten)
regions = ['Harzkreis', 'Wittenberg', 'Magdeburg']

# Preise pro Quadratmeter nach Regionen gruppieren und Regionen mit zu wenigen Datenpunkten ausschließen
min_samples = 10
region_groups = [data[data['address'].str.contains(region)]['price_per_m2'].dropna() for region in regions]
region_groups = [group for group in region_groups if len(group) >= min_samples]

# Überprüfen, welche Regionen genügend Datenpunkte haben
valid_regions = [region for region, group in zip(regions, region_groups) if len(group) >= min_samples]
print(f"Gültige Regionen: {valid_regions}")

# Einfaktorielle ANOVA
if len(region_groups) > 1:
    anova_stat, anova_pvalue = f_oneway(*region_groups)
    print(f"Einfaktorielle ANOVA: F-statistic = {anova_stat}, p-value = {anova_pvalue}")
else:
    print("Nicht genügend Datenpunkte für ANOVA-Test.")

# Kruskal-Wallis-Test
if len(region_groups) > 1:
    kruskal_stat, kruskal_pvalue = kruskal(*region_groups)
    print(f"Kruskal-Wallis Test: H-statistic = {kruskal_stat}, p-value = {kruskal_pvalue}")
else:
    print("Nicht genügend Datenpunkte für Kruskal-Wallis-Test.")

# Plot erstellen
if len(valid_regions) > 0:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='address', y='price_per_m2', data=data[data['address'].str.contains('|'.join(valid_regions))], order=valid_regions)
    plt.title('Price per m2 in Different Regions')
    plt.xlabel('Region')
    plt.ylabel('Price per m2')
    plt.xticks(rotation=45)
    plt.show()
else:
    print("Nicht genügend Datenpunkte zum Plotten.")
