import pandas as pd
from scipy.stats import ttest_ind, mannwhitneyu
import matplotlib.pyplot as plt
import seaborn as sns

# Daten laden
data = pd.read_csv('../../../../Desktop/Cleaned_HAUS_Properties.csv')

# Verfügbarkeit definieren (sofort verfügbar = 1, nach Vereinbarung = 0)
data['availability'] = data['available_from'].apply(lambda x: 1 if 'sofort' in str(x).lower() else 0)

# Preise pro Quadratmeter nach Verfügbarkeit gruppieren
immediate_prices = data[data['availability'] == 1]['price_per_m2']
negotiated_prices = data[data['availability'] == 0]['price_per_m2']

# Ungepaarter t-Test
if len(immediate_prices.dropna()) > 1 and len(negotiated_prices.dropna()) > 1:
    t_stat, t_pvalue = ttest_ind(immediate_prices.dropna(), negotiated_prices.dropna())
    print(f"Ungepaarter t-Test: t-statistic = {t_stat}, p-value = {t_pvalue}")
else:
    print("Nicht genügend Datenpunkte für ungepaarten t-Test.")

# Mann-Whitney U Test
if len(immediate_prices.dropna()) > 1 and len(negotiated_prices.dropna()) > 1:
    u_stat, u_pvalue = mannwhitneyu(immediate_prices.dropna(), negotiated_prices.dropna())
    print(f"Mann-Whitney U Test: U-statistic = {u_stat}, p-value = {u_pvalue}")
else:
    print("Nicht genügend Datenpunkte für Mann-Whitney U Test.")

# Plot erstellen
if len(immediate_prices.dropna()) > 0 and len(negotiated_prices.dropna()) > 0:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='availability', y='price_per_m2', data=data)
    plt.title('Price per m2 for Different Availabilities')
    plt.xlabel('Availability (Immediate=1, Negotiated=0)')
    plt.ylabel('Price per m2')
    plt.show()
else:
    print("Nicht genügend Datenpunkte zum Plotten.")
