import pandas as pd
from scipy.stats import f_oneway, kruskal
import matplotlib.pyplot as plt
import seaborn as sns

# Daten laden
data = pd.read_csv('../../../../Desktop/Cleaned_HAUS_Properties.csv')

# Objektarten definieren (Neu- und Altbau)
property_types = ['Neubau', 'Altbau']

# Preise pro Quadratmeter nach Objektarten gruppieren und Gruppen mit zu wenigen Datenpunkten ausschließen
min_samples = 10
type_groups = [data[data['type'].str.contains(p_type, case=False, na=False)]['price_per_m2'].dropna() for p_type in property_types]
type_groups = [group for group in type_groups if len(group) >= min_samples]

# Überprüfen, welche Objektarten genügend Datenpunkte haben
valid_property_types = [p_type for p_type, group in zip(property_types, type_groups) if len(group) >= min_samples]
print(f"Gültige Objektarten: {valid_property_types}")

# Einfaktorielle ANOVA
if len(type_groups) > 1:
    anova_stat, anova_pvalue = f_oneway(*type_groups)
    print(f"Einfaktorielle ANOVA: F-statistic = {anova_stat}, p-value = {anova_pvalue}")
else:
    print("Nicht genügend Datenpunkte für ANOVA-Test.")

# Kruskal-Wallis-Test
if len(type_groups) > 1:
    kruskal_stat, kruskal_pvalue = kruskal(*type_groups)
    print(f"Kruskal-Wallis Test: H-statistic = {kruskal_stat}, p-value = {kruskal_pvalue}")
else:
    print("Nicht genügend Datenpunkte für Kruskal-Wallis-Test.")

# Plot erstellen
if len(valid_property_types) > 0:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='type', y='price_per_m2', data=data[data['type'].str.contains('|'.join(valid_property_types), case=False, na=False)], order=valid_property_types)
    plt.title('Price per m2 for New vs Old Properties')
    plt.xlabel('Property Type')
    plt.ylabel('Price per m2')
    plt.xticks(rotation=45)
    plt.show()
else:
    print("Nicht genügend Datenpunkte zum Plotten.")
