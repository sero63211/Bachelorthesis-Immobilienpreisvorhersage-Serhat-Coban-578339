import pandas as pd


def read_csv_in_chunks(csv_file_path, chunk_size=1000):
    """
    Read a CSV file in chunks and print each chunk's data frame.

    Args:
    csv_file_path (str): Path to the CSV file.
    chunk_size (int): Number of rows per chunk.
    """
    try:
        # Initialize a counter for total rows
        total_rows = 0

        # Read the CSV file in chunks
        for chunk in pd.read_csv(csv_file_path, chunksize=chunk_size):
            total_rows += len(chunk)
            print(chunk)  # Print the current chunk of data
            print(f"Processed {total_rows} rows so far...")

        print(f"The total number of rows in the file '{csv_file_path}' is {total_rows}.")
        return total_rows

    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
        return None


# Usage example:
csv_file_path = 'Bundesländer_WOHNUNGEN_CSV/germany_apartments.csv'
read_csv_in_chunks(csv_file_path)
