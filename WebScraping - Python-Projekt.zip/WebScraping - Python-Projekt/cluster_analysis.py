import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns

# Daten laden
data = pd.read_csv('../../../Desktop/Cleaned_HAUS_Properties.csv')

# Relevante Faktoren auswählen
factors = ['rooms', 'living_space', 'property_area', 'bedrooms', 'bathrooms']

# Datenvorbereitung: Konvertieren und Skalieren der relevanten Faktoren
for col in factors:
    if data[col].dtype == 'object':
        data[col] = data[col].str.replace(',', '.').replace(['nil', 'None', ''], np.nan)
    data[col] = pd.to_numeric(data[col], errors='coerce')

data.dropna(subset=factors, inplace=True)

# Skalieren der Daten
scaler = StandardScaler()
scaled_data = scaler.fit_transform(data[factors])

# Clusteranalyse durchführen
kmeans = KMeans(n_clusters=3, random_state=42)  # Anzahl der Cluster kann angepasst werden
data['cluster'] = kmeans.fit_predict(scaled_data)

# Cluster-Zentren ausgeben
print("Cluster-Zentren:")
print(kmeans.cluster_centers_)

# Boxplot für Preis pro Quadratmeter in den Clustern
plt.figure(figsize=(10, 6))
sns.boxplot(x='cluster', y='price_per_m2', data=data)
plt.title('Price per m2 in Different Clusters')
plt.xlabel('Cluster')
plt.ylabel('Price per m2')
plt.show()

# Paarweise Scatterplots mit Clustern
sns.pairplot(data, hue='cluster', vars=factors)
plt.suptitle('Pairwise Scatterplots of Factors by Cluster', y=1.02)
plt.show()

# Cluster-Analyse für Preisunterschiede
for cluster in data['cluster'].unique():
    cluster_data = data[data['cluster'] == cluster]
    price_mean = cluster_data['price_per_m2'].mean()
    price_std = cluster_data['price_per_m2'].std()
    print(f"Cluster {cluster}: mean price per m2 = {price_mean:.2f}, std dev = {price_std:.2f}")
