import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# Daten laden
data = pd.read_csv('../../../../Desktop/Cleaned_HAUS_Properties.csv')

# Debugging-Ausgabe, um die ersten Zeilen der Daten zu überprüfen
print("Erste Zeilen der ursprünglichen Daten:")
print(data.head())

# Konvertieren der relevanten Spalten in numerische Formate
columns_to_convert = ['rooms', 'living_space', 'property_area', 'bedrooms', 'bathrooms', 'garage_parking', 'buyer_commission']
for col in columns_to_convert:
    # Nur wenn die Spalte String-Werte enthält, die ersetzt werden müssen
    if data[col].dtype == 'object':
        data[col] = data[col].str.replace(',', '.').replace(['nil', 'None', ''], np.nan)
    data[col] = pd.to_numeric(data[col], errors='coerce')

# Debugging-Ausgabe, um die Anzahl der NaN-Werte pro Spalte zu überprüfen
print("\nAnzahl der NaN-Werte pro Spalte nach Konvertierung:")
print(data[columns_to_convert].isna().sum())

# Fehlende Werte auffüllen
data['garage_parking'] = data['garage_parking'].fillna(0)
data['buyer_commission'] = data['buyer_commission'].fillna(0)
data['bedrooms'] = data['bedrooms'].fillna(data['bedrooms'].median())
data['bathrooms'] = data['bathrooms'].fillna(data['bathrooms'].median())

# Debugging-Ausgabe nach dem Auffüllen der fehlenden Werte
print("\nAnzahl der NaN-Werte pro Spalte nach dem Auffüllen:")
print(data[columns_to_convert].isna().sum())

# Bereinigen von NaN-Werten
data.dropna(subset=columns_to_convert + ['price_per_m2'], inplace=True)

# Debugging-Ausgabe, um die Anzahl der verbleibenden Zeilen zu überprüfen
print(f"\nAnzahl der verbleibenden Zeilen nach Bereinigung: {data.shape[0]}")

# Daten vorbereiten
X = data[columns_to_convert]
y = data['price_per_m2']

# Überprüfen, ob nach der Bereinigung noch Daten vorhanden sind
if X.shape[0] == 0 or y.shape[0] == 0:
    raise ValueError("Keine Daten nach der Bereinigung vorhanden. Überprüfen Sie die Eingabedaten und die Bereinigungsschritte.")

# Daten in Trainings- und Testdatensätze aufteilen
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Hauptkomponentenanalyse durchführen
pca = PCA(n_components=3)
X_train_pca = pca.fit_transform(X_train)
X_test_pca = pca.transform(X_test)

# Lineares Regressionsmodell erstellen und trainieren
model = LinearRegression()
model.fit(X_train_pca, y_train)

# Vorhersagen machen
y_pred = model.predict(X_test_pca)

# Modellleistung bewerten
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Ergebnisse ausgeben
print(f"Mean Squared Error: {mse:.2f}")
print(f"R^2 Score: {r2:.2f}")

# Plot der tatsächlichen gegen die vorhergesagten Werte
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred, alpha=0.3)
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--', lw=2)
plt.title('PCA + Regression: Actual vs. Predicted Prices per m2')
plt.xlabel('Actual Prices per m2')
plt.ylabel('Predicted Prices per m2')
plt.show()
