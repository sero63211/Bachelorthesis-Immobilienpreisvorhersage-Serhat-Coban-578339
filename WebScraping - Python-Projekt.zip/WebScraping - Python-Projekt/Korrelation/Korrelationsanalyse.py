import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Pfad zur CSV-Datei
data = pd.read_csv('../../../../Desktop/Cleaned_HAUS_Properties.csv')

# Daten laden
pd.set_option('display.max_columns', 20)  # Anzahl der maximal angezeigten Spalten

# Liste aller möglichen numerischen Spalten
possible_numeric_columns = [
    'price', 'rooms', 'living_space', 'property_area', 'price_per_m2',
    'usable_area', 'bedrooms', 'bathrooms', 'garage_parking', 'log_price'
]

# Konvertiere und bereinige alle Spalten, die numerisch sein könnten
for col in possible_numeric_columns:
    data[col] = pd.to_numeric(data[col].astype(str).replace('nil', np.nan).str.replace(',', '.'), errors='coerce')

# Überprüfen, welche Spalten vollständig aus NaN-Werten bestehen
all_nan_columns = [col for col in possible_numeric_columns if data[col].isna().all()]

# Entfernen dieser Spalten aus der Analyse
for col in all_nan_columns:
    possible_numeric_columns.remove(col)

# Informieren, welche Spalten entfernt wurden
if all_nan_columns:
    print(f"Removed columns due to only NaN values: {all_nan_columns}")
else:
    print("No columns were completely NaN.")

# Erstellen einer Korrelationsmatrix für alle numerischen Spalten, die gültige Daten enthalten
correlation_matrix = data[possible_numeric_columns].corr()

# Ausgabe der Korrelationsmatrix
print("Korrelationsmatrix für alle numerischen Spalten:")
print(correlation_matrix)

# Visualisierung der Korrelationsmatrix als Heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
plt.title('Korrelationsmatrix für alle numerischen Immobilienmerkmale')
plt.show()

# Optional: Scatterplots für paarweise Korrelationen, wenn noch genügend Spalten übrig sind
if len(possible_numeric_columns) > 1:
    sns.pairplot(data[possible_numeric_columns])
    plt.suptitle('Paarweise Scatterplots der Immobiliendaten', y=1.02)
    plt.show()
# Speichern der Korrelationsmatrix in eine CSV-Datei
correlation_matrix.to_csv('/Users/sero/Documents/Bachelor/WebScraping/correlation_matrix.csv')
