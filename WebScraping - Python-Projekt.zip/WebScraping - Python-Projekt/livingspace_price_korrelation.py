import pandas as pd
import numpy as np
from scipy.stats import pearsonr
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
import seaborn as sns

# Pfad zur Immobilien-Datei
data_path = '../../../Desktop/Cleaned_HAUS_Properties.csv'

# Laden der Immobilien-Daten
data = pd.read_csv(data_path)

# Entfernen von Einträgen mit fehlenden Werten in den relevanten Spalten
data = data.dropna(subset=['price', 'living_space'])

# Entfernen von unplausiblen Null- oder Negativwerten
data = data[data['price'] > 0]
data = data[data['living_space'] > 0]

# Log-Transformation der Daten
data['log_price'] = np.log(data['price'])
data['log_living_space'] = np.log(data['living_space'])

# Entfernen von Ausreißern (z.B. Daten, die mehr als 3 Standardabweichungen vom Mittelwert entfernt sind)
data = data[(np.abs(data['log_price'] - data['log_price'].mean()) <= (3 * data['log_price'].std()))]
data = data[(np.abs(data['log_living_space'] - data['log_living_space'].mean()) <= (3 * data['log_living_space'].std()))]

# Korrelationsanalyse
correlation, p_value = pearsonr(data['log_price'], data['log_living_space'])
print(f"Korrelation zwischen logarithmiertem Preis und logarithmierter Wohnfläche: {correlation:.2f}, p-Wert: {p_value:.4f}")

# Daten für die Regression vorbereiten
X = data[['log_living_space']]
y = data['log_price']

# Daten in Trainings- und Testdatensätze aufteilen
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Lineares Regressionsmodell erstellen und trainieren
model = LinearRegression()
model.fit(X_train, y_train)

# Vorhersagen machen
y_pred = model.predict(X_test)

# Modellleistung bewerten
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse:.2f}")
print(f"R^2 Score: {r2:.2f}")

# Ergebnisse visualisieren
plt.figure(figsize=(10, 6))
plt.scatter(X_test, y_test, color='blue', alpha=0.5, label='Tatsächliche Werte')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Vorhergesagte Werte')
plt.title('Lineare Regression: Logarithmierter Preis vs. Logarithmierte Wohnfläche')
plt.xlabel('Logarithmierte Wohnfläche (m²)')
plt.ylabel('Logarithmierter Preis (€)')
plt.legend()
plt.show()

# Histogramm der Residuen
residuals = y_test - y_pred
plt.figure(figsize=(10, 6))
sns.histplot(residuals, kde=True)
plt.title('Histogramm der Residuen')
plt.xlabel('Residuen')
plt.ylabel('Häufigkeit')
plt.show()

# Statistik der Residuen
print("\nStatistik der Residuen:")
print(residuals.describe())

# Tatsächliche vs. vorhergesagte Werte ausgeben
print("\nErste 10 tatsächliche vs. vorhergesagte logarithmierte Preise:")
for real, pred in zip(y_test[:10], y_pred[:10]):
    print(f"Tatsächlich: {np.exp(real):.2f}, Vorhergesagt: {np.exp(pred):.2f}")
