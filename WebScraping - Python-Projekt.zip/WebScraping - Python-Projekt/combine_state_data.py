"""
Dieses Skript durchsucht ein angegebenes Verzeichnis nach CSV-Dateien,
liest sie ein und kombiniert alle gefundenen Dateien in einen einzigen
zusammengeführten DataFrame. Der kombinierte DataFrame wird dann in eine
neue CSV-Datei exportiert. Das Skript ist nützlich, wenn man mehrere CSV-Dateien
hat, die zusammengeführt werden müssen, wie z.B. Immobilien-Daten aus
verschiedenen Bundesländern in Deutschland.
"""

import os
import glob
import pandas as pd


def combine_all_csv_to_one(directory):
    """
    Diese Funktion durchsucht das angegebene Verzeichnis nach CSV-Dateien,
    liest sie ein und kombiniert sie zu einer einzigen CSV-Datei.

    Args:
        directory (str): Das Verzeichnis, in dem nach CSV-Dateien gesucht werden soll.

    Returns:
        None
    """
    # Muster für das Auffinden aller CSV-Dateien im Verzeichnis
    pattern = os.path.join(directory, '*.csv')
    csv_files = glob.glob(pattern)

    print(f"Found {len(csv_files)} CSV files to combine.")

    # Liste zur Speicherung der DataFrames
    df_list = []

    # Einlesen jeder gefundenen CSV-Datei
    for file in csv_files:
        df = pd.read_csv(file)
        entries_count = len(df)
        print(f"Reading {file} with {entries_count} entries.")
        df_list.append(df)

    # Zusammenführen aller DataFrames in einen einzigen DataFrame
    if df_list:
        combined_df = pd.concat(df_list, ignore_index=True)
        total_entries = len(combined_df)
        print(f"Total entries after concatenation: {total_entries}")

        # Name der Datei, in der der zusammengeführte DataFrame gespeichert wird
        output_file = 'germany_apartments.csv'
        combined_df.to_csv(os.path.join(directory, output_file), index=False)

        print(f"All CSV files have been combined into {output_file} containing {total_entries} total entries.")
    else:
        print("No CSV files found.")


# Verwendung des Skripts
if __name__ == '__main__':
    current_directory = "./Bundesländer_WOHNUNGEN_CSV/"  # Verzeichnis, in dem das Skript ausgeführt wird
    combine_all_csv_to_one(current_directory)
