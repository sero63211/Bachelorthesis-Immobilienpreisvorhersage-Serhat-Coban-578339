import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns

# Daten laden
cleaned_file_path = '../../../Desktop/Cleaned_HAUS_Properties.csv'
data = pd.read_csv(cleaned_file_path)

# Auswahl der relevanten numerischen Merkmale für die Clusteranalyse
numerical_cols = ['price', 'living_space', 'property_area', 'price_per_m2', 'usable_area']
data = data[numerical_cols]

# Fehlende Werte mit dem Median füllen
for col in numerical_cols:
    data[col] = data[col].fillna(data[col].median())

# Standardisierung der Daten
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data)

# Durchführung der K-Means-Clusteranalyse
kmeans = KMeans(n_clusters=3, random_state=42)
clusters = kmeans.fit_predict(data_scaled)
data['Cluster'] = clusters

# Ausgabe der Clusterzentren und Anzahl der Elemente in jedem Cluster
cluster_centers = kmeans.cluster_centers_
cluster_counts = pd.Series(clusters).value_counts()

print("Clusterzentren (skaliert):\n", cluster_centers)
print("\nClusterzentren (original):\n", scaler.inverse_transform(cluster_centers))
print("\nAnzahl der Elemente in jedem Cluster:\n", cluster_counts)

# Statistische Zusammenfassung für jedes Cluster
for cluster in range(3):
    print(f"\nStatistische Zusammenfassung für Cluster {cluster}:")
    cluster_data = data[data['Cluster'] == cluster]
    print(cluster_data.describe())

# Korrelationen innerhalb jedes Clusters
for cluster in range(3):
    print(f"\nKorrelationen innerhalb von Cluster {cluster}:")
    cluster_data = data[data['Cluster'] == cluster].drop(columns='Cluster')
    correlations = cluster_data.corr()
    print(correlations)

# Ergebnisse visualisieren
sns.pairplot(data, hue='Cluster', diag_kind='kde')
plt.suptitle('Pairplot der Cluster', y=1.02)
plt.show()

# Boxplots zur Verteilung der Variablen in den Clustern
for col in numerical_cols:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Cluster', y=col, data=data)
    plt.title(f'Boxplot von {col} in den Clustern')
    plt.show()
