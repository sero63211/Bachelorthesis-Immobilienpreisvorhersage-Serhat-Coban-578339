import pandas as pd

# Daten laden
data = pd.read_csv("../../../Desktop/Cleaned_HAUS_Properties.csv")

# Schiefe und Kurtosis für die Spalte "price" berechnen
price_schiefe = data['price'].skew()
price_kurtosis = data['price'].kurt()

print("Schiefe (Skewness):", price_schiefe)
print("Kurtosis:", price_kurtosis)
