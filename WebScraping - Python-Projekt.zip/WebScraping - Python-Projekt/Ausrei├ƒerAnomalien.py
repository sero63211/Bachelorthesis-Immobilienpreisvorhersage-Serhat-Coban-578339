import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import zscore

# Daten laden (angenommen, die Daten sind bereits gereinigt)
data = pd.read_csv("../../../Desktop/Cleaned_HAUS_Properties.csv")

# Auswahl der relevanten numerischen Merkmale
numerical_cols = ['living_space' ]

# Identifikation der Ausreißer mittels IQR-Methode (Boxplot-Logik)
def detect_outliers_iqr(df, column):
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = df[(df[column] < lower_bound) | (df[column] > upper_bound)]
    return outliers

outliers_iqr = pd.DataFrame()
for col in numerical_cols:
    outliers_iqr = outliers_iqr._append(detect_outliers_iqr(data, col))

print(f"Anzahl der Ausreißer (IQR-Methode): {outliers_iqr.shape[0]}")
print(outliers_iqr[numerical_cols].describe())

# Z-Score Methode zur Erkennung von Ausreißern
data_cleaned = data[numerical_cols].dropna()  # Sicherstellen, dass keine fehlenden Werte vorhanden sind

z_scores = np.abs(zscore(data_cleaned))
outliers_zscore = data_cleaned[(z_scores > 3).any(axis=1)]

print(f"Anzahl der Ausreißer (Z-Score Methode): {outliers_zscore.shape[0]}")
print(outliers_zscore.describe())

# Visualisierung der Ausreißer mittels Boxplot
for col in numerical_cols:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x=data[col])
    plt.title(f'Boxplot von {col} mit Ausreißern')
    plt.xlabel(col)
    plt.show()
