import pandas as pd
import re
import os

# Liste der Dateipfade
file_paths = [
    './BundesLänder_HAUS_CSV/properties_baden-wuerttemberg.csv',
    './BundesLänder_HAUS_CSV/properties_bayern.csv',
    './BundesLänder_HAUS_CSV/properties_berlin.csv',
    './BundesLänder_HAUS_CSV/properties_brandenburg.csv',
    './BundesLänder_HAUS_CSV/properties_bremen.csv',
    './BundesLänder_HAUS_CSV/properties_hamburg.csv',
    './BundesLänder_HAUS_CSV/properties_hessen.csv',
    './BundesLänder_HAUS_CSV/properties_mecklenburg-vorpommern.csv',
    './BundesLänder_HAUS_CSV/properties_niedersachsen.csv',
    './BundesLänder_HAUS_CSV/properties_nordrhein-westfalen.csv',
    './BundesLänder_HAUS_CSV/properties_thueringen.csv',
    './BundesLänder_HAUS_CSV/properties_saarland.csv',
    './BundesLänder_HAUS_CSV/properties_sachsen.csv',
    './BundesLänder_HAUS_CSV/properties_sachsen-anhalt.csv',
    './BundesLänder_HAUS_CSV/properties_rheinland-pfalz.csv',
    './BundesLänder_HAUS_CSV/properties_schleswig-holstein.csv'
]

# Zielverzeichnis für bereinigte Daten
output_dir = './Cleaned_Bundesland_HAUS'
os.makedirs(output_dir, exist_ok=True)

# Durchlaufen aller Dateien und Anwenden der Bereinigungsfunktionen
for file_path in file_paths:
    data = pd.read_csv(file_path)

    # Preis-Spalte bereinigen
    def clean_price(value):
        if isinstance(value, str):
            value = value.replace('€', '').replace('.', '').replace(',', '.').strip()
            if 'Auf Anfrage' in value or value == '':
                return None
            try:
                return float(value)
            except ValueError:
                return None
        return value if value is not None and value != '' else None

    data['price'] = data['price'].apply(clean_price)

    # Funktion zur Reinigung und Konvertierung von Flächenangaben
    def clean_area(value):
        if isinstance(value, str):
            value = re.sub(r'[^\d,]', '', value).replace(',', '.')
            try:
                return float(value) if value else None
            except ValueError:
                return None
        return value

    data['living_space'] = data['living_space'].apply(clean_area)
    data['property_area'] = data['property_area'].apply(clean_area)

    # Weitere Bereinigungen für andere Spalten
    def clean_generic_numeric(value):
        if isinstance(value, str):
            value = re.sub(r'[^\d,]', '', value).replace(',', '.')
            try:
                return float(value) if value else None
            except ValueError:
                return None
        return value

    data['price_per_m2'] = data['price_per_m2'].apply(clean_generic_numeric)
    data['usable_area'] = data['usable_area'].apply(clean_generic_numeric)

    # Sicherstellen, dass die Spalten numerisch behandelt werden
    numeric_columns = ['living_space', 'property_area', 'price_per_m2', 'usable_area']
    for column in numeric_columns:
        data[column] = pd.to_numeric(data[column], errors='coerce')

    # Entfernen von Datenzeilen mit bestimmten Bedingungen
    data = data[(data['living_space'] > 5) & (data['property_area'] > 5) & (data['price_per_m2'] > 5)]

    # Duplikate entfernen
    data.drop_duplicates(inplace=True)

    # Bereinigte Daten speichern
    output_path = os.path.join(output_dir, os.path.basename(file_path))
    data.to_csv(output_path, index=False)
    print(f'Daten bereinigt und gespeichert in: {output_path}')

print("Alle Daten wurden bereinigt und gespeichert.")
