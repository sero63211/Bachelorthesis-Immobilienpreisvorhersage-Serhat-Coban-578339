import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Daten laden (Stellen Sie sicher, dass der Pfad zur CSV-Datei korrekt ist)
data = pd.read_csv('../../../Desktop/Cleaned_HAUS_Properties.csv')
pd.set_option('display.max_columns', 20)  # Anzahl der maximal angezeigten Spalten

# Überprüfung der ersten Zeilen des Datensatzes, um die Datenstruktur zu verstehen
print("Die ersten Zeilen des Datensatzes:")
print(data.head())

# Überprüfung der Beschreibung der Daten für ein besseres Verständnis der Verteilungen
print("\nBeschreibung der numerischen Daten:")
print(data.describe())

# Daten vorbereiten
X = data[['price_per_m2']]  # Feature: Preis pro Quadratmeter
y = data['price']           # Zielvariable: Gesamtpreis der Immobilie

# Daten in Trainings- und Testdatensätze aufteilen
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Lineares Regressionsmodell erstellen und trainieren
model = LinearRegression()
model.fit(X_train, y_train)

# Modell bewerten
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# Ausgabe der Modellleistung
print(f"\nModell Mean Squared Error: {mse:.2f}")
print(f"Modell R^2 Score: {r2:.2f}")

# Ausgabe von tatsächlichen gegenüber vorhergesagten Werten zur visuellen Überprüfung
print("\nTatsächliche vs. Vorhergesagte Preise:")
for real, pred in zip(y_test[:10], y_pred[:10]):
    print(f"Tatsächlich: {real}, Vorhergesagt: {pred:.2f}")
